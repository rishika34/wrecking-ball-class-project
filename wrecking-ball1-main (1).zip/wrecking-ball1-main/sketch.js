

function setup() {
  createCanvas(800,400);
  
}

function draw() {
  background(0);  
  
}